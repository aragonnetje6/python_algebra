# python_algebra

simple expression tree with derivatives and basic integrals implemented in python
